#pragma once

#include "Model.h"

struct Bone {

};

struct Skeleton {

};