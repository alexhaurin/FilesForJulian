#pragma once

#include <chrono>
#include <thread>

#include "Vulkan/Vulkan.h"

#define SCREEN_WIDTH  uint32_t(2400)
#define SCREEN_HEIGHT uint32_t(1800)
//#define RENDERER_PARALLEL_PROJECTION uint8_t(128)
//#define RENDERER_WIREFRAME_DRAWING   uint8_t(64)

class Scene;

enum class eRendererState {
	Created,
	Initialized,
	Destroyed
};

class Renderer {
public:
	using Vec3 = glm::vec3;
	using Vec2 = glm::vec3;

	Renderer(const Renderer&) = delete;
	static Renderer* Get() {
		return s_instance;
	}

	static void Initialize(const std::shared_ptr<Scene> in_scene, uint8_t in_flags = 0) { Renderer::Get()->InitializeImpl(in_scene, in_flags); }
	static void Destroy() { Renderer::Get()->DestroyImpl(); }

	static void DisplayScene(Scene* in_scene) { Renderer::Get()->DisplaySceneImpl(in_scene); }
	static void DisplayScene(Scene* in_scene, const std::shared_ptr<Camera> in_camera) { Renderer::Get()->DisplaySceneImpl(in_scene, in_camera); }
	static VertexData LoadOBJ(const char* in_filepath) { return Renderer::Get()->LoadOBJImpl(in_filepath); }
	static TextureData LoadTexture(const char* in_filepath) { return Renderer::Get()->LoadTextureImpl(in_filepath); }

	//void SetProjectionFlag(uint8_t in_flag) { m_bitFieldRenderFlags |= in_flag; }
	//void ResetProjectionFlag(uint8_t in_flag) { m_bitFieldRenderFlags ^= in_flag; }
	//void ResetAllProjectionFlags() { m_bitFieldRenderFlags = uint8_t(0); }

private:
	// Private implemented functions
	Renderer() {};

	void InitializeImpl(const std::shared_ptr<Scene> in_scene, uint8_t in_flags = 0);
	void DestroyImpl();

	void DisplaySceneImpl(Scene* in_scene);
	void DisplaySceneImpl(Scene* in_scene, const std::shared_ptr<Camera> in_camera);
	VertexData LoadOBJImpl(const char* in_filepath);
	TextureData LoadTextureImpl(const char* in_filepath);

	// Private Member Variables
	static Renderer* s_instance;
	Vulkan* m_pVulkanInstance = nullptr;

	eRendererState m_state = eRendererState::Created;
	uint8_t m_bitFieldRenderFlags = 0;

	GLFWwindow* m_pWindow = nullptr;
};