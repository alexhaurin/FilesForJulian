#pragma once

#include <glm\vec3.hpp>

enum class eLightTypes {
	Directional,
	Point,
	Spotlight
};

struct LightData {
	using glScalarF = float;
	using glScalarUI = uint32_t;

	alignas(sizeof(glScalarUI)) eLightTypes type = eLightTypes::Directional;

	glScalarF constant  = 1.0f;
	glScalarF linear    = 0.09f;
	glScalarF quadratic = 0.032f;

	glScalarF strength  = 1.0f;
	glScalarF ambient   = 0.0f;
	glScalarF specular  = 0.1f;
					    
	glScalarF inCutOff    = 0.9f;
	glScalarF outCutOff   = 0.8f;
	glScalarF PADDING1;
	glScalarF PADDING2;

	alignas(sizeof(glScalarF) * 4)  glm::vec3  position   = glm::vec3(0.0f, 0.0f, 0.0f);
	alignas(sizeof(glScalarF) * 4)  glm::vec3  direction  = glm::vec3(0.0f, 0.0f, 1.0f);
	alignas(sizeof(glScalarUI) * 4) glm::uvec3 color      = glm::vec3(1.0f, 1.0f, 1.0f);
};