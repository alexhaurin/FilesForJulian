#pragma once

#include <vector>
#include <iostream>
#include <fstream>

#include <GLM/vec2.hpp>

#include "Model.h"
#include "../Scene.h"

class AnimationPlayer;

enum class eAnimationPlayerState {
	Created,
	Initialized,
	Destroyed
};

struct Frame {
	using Vec2 = glm::vec2;

	Vec2 coords = Vec2(0.0f, 0.0f);
	Vec2 size   = Vec2(1.0f, 1.0f);
	int num     = 0;
};

class Animation {
public:
	friend AnimationPlayer;

	void AddFrame(const Frame& in_frame) {
		for (int i = 0; i < m_frames.size(); ++i)
		{
			if (m_frames[i].num <= in_frame.num)
			{
				m_frames.insert(m_frames.begin() + i, in_frame);
				return;
			}
		}

		m_frames.push_back(in_frame);
	};

	std::string GetName() const { return m_name; }
	void SetName(const std::string& in_name) { m_name = in_name; }
	float GetFPS() const { return m_fps; }
	void SetFPS(const float in_fps) { m_fps = in_fps; }
	void SetSpriteSheet(const TextureData& in_spriteSheet) { m_spriteSheet = in_spriteSheet; }
	uint32_t GetFrameCount() const { return m_frames.size(); }

private:
	std::vector<Frame> m_frames;

	std::string m_name = "";
	float m_fps = 10.0f;
	TextureData m_spriteSheet;
};

class AnimationPlayer {
public:
	using Vec2 = glm::vec2;
	using Vec3 = glm::vec3;

	void Initialize();
	void Destroy();

	void Update(const float in_dt);
	void Draw(const std::shared_ptr<Scene> in_scene);

	void Pause();
	void Play();

	void SetFlipped(bool in_flipped);
	Vec2 GetPosition() const { return m_tile.GetPosition(); }
	void SetPosition(const Vec2& in_position) { m_tile.SetPosition(Vec3(in_position, 0)); }
	void SetPosition(const Vec3& in_position) { m_tile.SetPosition(in_position); }

	void StartAnimation(const char* in_name);
	void LoadAnimations(const std::string& in_folderPath);

	Animation* GetActiveAnimation() { return m_pActiveAnimation; }
	eAnimationPlayerState GetState() const { return m_state; }
	bool IsInitialized() const { return GetState() == eAnimationPlayerState::Initialized; }

private:
	void SetActiveAnimation(Animation* in_pAnim);
	void SetState(const eAnimationPlayerState in_state) { m_state = in_state; }

	eAnimationPlayerState m_state = eAnimationPlayerState::Created;

	std::vector<Animation> m_animations;
	Animation* m_pActiveAnimation = nullptr;

	float m_tic = 0.0f;
	bool m_playing = true;
	Model m_tile;
};