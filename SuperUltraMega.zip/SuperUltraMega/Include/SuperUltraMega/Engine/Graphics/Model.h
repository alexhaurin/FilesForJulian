#pragma once

#include <vector>
#include <memory>
#include <iostream>

#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "ModelData.h"

class Model {
public:
	using Vec2 = glm::vec2;
	using Vec3 = glm::vec3;
	using Vec4 = glm::vec4;
	using Mat3 = glm::mat3;
	using Mat4 = glm::mat4x4;

	Model();
	Model(const VertexData& in_vData);
	Model(const VertexData& in_vData, const TextureData& in_tData);

	void SetVertexData(VertexData in_data) { m_vertexData = in_data; }
	void SetTextureData(TextureData in_data) { m_textureData = in_data; }

	Vec3 GetPosition() const { return m_position; }
	Vec3 GetRotation() const { return m_rotation; }
	Vec3 GetScale()    const { return m_scale;    }

	void SetPosition(const Vec3& in_position) { m_position = in_position; }
	void SetRotation(const Vec3& in_rotation) { m_rotation = in_rotation; }

	void SetScale(const Vec3& in_scale) { m_scale = in_scale; }
	void SetColor(const Vec4& in_color) { m_color = in_color; }
	void SetColor(const Vec3& in_color) { m_color = Vec4(in_color.x, in_color.y, in_color.z, 1.0f); }

	void SetTileSize(const Vec2& in_dim) { m_tileSize = in_dim; }
	void SetTileTexCoords(const Vec2& in_coords) { m_texCoords = in_coords; }

	struct PushConstant {
		Mat4 model = Mat4(1.0f);
		Vec4 color = Vec4(1.0f);

		Vec2 texCoordAdd = Vec2(0.0f, 0.0f);
		Vec2 texCoordMult = Vec2(1.0f, 1.0f);

		int32_t textureData = -1;
	};

private:
	Vec3 m_scale    = Vec3(1.0f, 1.0f, 1.0f);
	Vec3 m_rotation = Vec3(0.0f, 0.0f, 0.0f);
	Vec3 m_position = Vec3(0.0f, 0.0f, 0.0f);

	Vec4 m_color = Vec4(1.0f);

	Vec2 m_tileSize = Vec2(1.0f);
	Vec2 m_texCoords = Vec2(0.0f, 0.0f);

	TextureData m_textureData;
	VertexData  m_vertexData;

public:
	void GetPushConstantData(Model::PushConstant* in_pData) const;

	const TextureData* GetTextureData() const { return &m_textureData; }
	const VertexData*  GetVertexData() const { return &m_vertexData; }
};