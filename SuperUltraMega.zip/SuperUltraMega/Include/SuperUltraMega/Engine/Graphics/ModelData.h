#pragma once

#include <cstdint>

enum class eModelType {
	UNTEXTURED_MODEL,
	TEXTURED_MODEL,
	TEXT
};

struct VertexData {
	uint32_t indices[2] = { 0, 0 };
};

struct TextureData {
	int32_t index = -1;
	glm::vec2 dimensions;
};