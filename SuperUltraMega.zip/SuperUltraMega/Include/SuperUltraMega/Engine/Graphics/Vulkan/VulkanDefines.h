#pragma once

#define INDEX_TYPE uint32_t
#define SHADER_PATH_VERT "Shaders/vert.spv"
#define SHADER_PATH_FRAG "Shaders/frag.spv"

//#define CULL_MODE VK_CULL_MODE_BACK_BIT
#define CULL_MODE VK_CULL_MODE_NONE

#define CLEAR_COLOR 230.0f/255.0f, 50.0f/255.0f, 44.0f/255.0f, 1.0f

#define LIGHT_POS 0.0f, 0.0f, 1.0f
#define LIGHT_COUNT 1

#define MAX_TEXTURE_COUNT 2

#define MAX_BONE_INFLUENCE 10