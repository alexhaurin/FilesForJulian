#pragma once

#include <vector>

#include "Vulkan/VulkanDefines.h"

struct Vertex;

struct Shape {
	Shape();
	Shape(int in_num);

	INDEX_TYPE indices[2];

	std::vector<Vertex> m_vertexList;
	std::vector<INDEX_TYPE> m_indexList;
};

