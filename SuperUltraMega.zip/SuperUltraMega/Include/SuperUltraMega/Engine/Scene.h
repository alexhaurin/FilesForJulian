#pragma once

#include <memory>

#include "Graphics/Renderer.h"
#include "RigidBody.h"

#define SCENE_DRAW_LIMIT_MODELS uint32_t(100)
#define SCENE_DRAW_LIMIT_SHAPES uint32_t(100)

class Scene : std::enable_shared_from_this<Scene> {
public:
	friend Renderer;

	using Vec2 = glm::vec2;
	using Vec3 = glm::vec3;
	using Mat4 = glm::mat4x4;

	void Initialize();
	void Destroy();

	void Update(const float in_dt);

	GLFWwindow* GetWindow() { return m_pWindow; }

	void Clear();
	void Draw(const Model* in_pModel);
	void Display(const std::shared_ptr<Camera> in_camera);
	void Display();

	void AddRigidBody(std::shared_ptr<RigidBody3D> in_body);

private:
	std::vector<Model>& GetModelDrawList() { return m_modelDrawList; }
	std::vector<Shape>& GetShapeDrawList() { return m_shapeDrawList; }

	// Graphics
	GLFWwindow* m_pWindow = nullptr;

	std::vector<Model> m_modelDrawList;
	std::vector<Shape> m_shapeDrawList;

	// Bullet 3D
	btDiscreteDynamicsWorld* m_pPhysicsWorld; // Basically a container for rigid bodies
	std::vector<std::shared_ptr<RigidBody3D>> m_rigidBodies;

	btDefaultCollisionConfiguration* m_collisionConfiguration;
	btCollisionDispatcher* m_dispatcher;
	btBroadphaseInterface* m_overlappingPairCache;
	btSequentialImpulseConstraintSolver* m_solver;
};