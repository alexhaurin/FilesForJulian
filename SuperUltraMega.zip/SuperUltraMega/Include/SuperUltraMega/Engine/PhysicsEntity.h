#pragma once

#include "Entity.h"

class PhysicsEntity : public Entity {
public:
	using Vec3 = glm::vec3;

	PhysicsEntity();
	~PhysicsEntity();
	void Initialize(const ConstructInfoRigidBody3D* in_pBodyInfo, const ConstructInfoCollisionShape* in_colBoxInfo, const std::shared_ptr<Scene> in_scene);
	void Initialize(const ConstructInfoRigidBody3D* in_pBodyInfo, const std::vector<ConstructInfoCollisionShape*>& in_colBoxInfos, const std::shared_ptr<Scene> in_scene);
	void Destroy();

	virtual void RunFrame();
	virtual void Render(const std::shared_ptr<Scene> in_scene);

	Vec3 GetBodyPosition() const;
	Vec3 GetBodyRotation() const;

private:
	std::shared_ptr<RigidBody3D> m_rigidBody = std::make_shared<RigidBody3D>();
};