#pragma once

#include <glm/glm.hpp>

#define CAMERA_POSITION 0.0f, 0.0f, 5.0f
#define CAMERA_FORWARD  0.0f, 0.0f, -1.0f
#define CAMERA_UP       0.0f, 1.0f, 0.0f

struct ViewData {
	using Vec3 = glm::vec3;

	Vec3 target;
	Vec3 eye;
	Vec3 up;
};

class Camera {
public:
	using Vec3 = glm::vec3;
	using Mat4x4 = glm::mat4x4;

	ViewData GetViewData();
	Vec3 GetDirection();
	Vec3 GetUp();
	Vec3 GetPosition() const { return m_position; }

	void Move(const Vec3& in_movement) { m_position += in_movement; }
	void Strafe(const float in_movement);
	void Forward(const float in_movement);
	void Up(const float in_movement);
	
	void RotatePitch(const float in_rad) { m_pitch += in_rad; }
	void RotateYaw(const float in_rad)   { m_yaw += in_rad; }
	//void RotateRoll(float in_rad)  { m_roll += in_rad; }

	static ViewData GetConstViewData();
	

private:
	Vec3 m_position = Vec3(CAMERA_POSITION);
	Vec3 m_forward  = Vec3(CAMERA_FORWARD);
	Vec3 m_up       = Vec3(CAMERA_UP);
	
	float m_pitch = 0.0f;
	float m_yaw   = 0.0f;
	float m_roll  = 0.0f;
}; 